create function newid() returns uuid
    language sql
as
$$
select md5(random()::text || clock_timestamp()::text)::uuid
$$;

alter function newid() owner to postgres;

